<div class="container my-5">
    <div class="alert alert-success"> Informações salvas com sucesso.  </div>
    <a href="../news" class="btn btn-primary"> Índice de notícias </a>
    <a href="../news/create" class="btn btn-primary">Cadastrar nova notícias </a>

</div>