<div class="container my-5"> 

    <h2> <?php echo $news['title']; ?> </h2>
    <p>  <?php echo $news['body']; ?> </p>

</div>


<div class="container my-5">


    <a href="../../news" class="btn btn-primary"> Índice de notícias </a>
    <a href="../../news/create" class="btn btn-success">Cadastrar nova notícias </a>

</div>