

<div class="container my-5">

 <a href="https://www.coupled.com.br"  target="_blank" style="text-decoration: none;">  <strong>   <em>&copy; 2021</em> - Coupled Dev Team  </strong> </a>

</div>
</body>
</html>

